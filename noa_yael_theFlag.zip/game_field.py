import random
import consts

# The matrix (game field)
matrix = []
#list of the top left corners (row, col) of the mines
mines = []


def build():
    """building a new board an empty matrix, a flag in the bottom-right corner, and random mines."""
    global matrix, mines
    matrix = [[consts.EMPTY for _ in range(consts.BOARD_COLS)]
              for _ in range(consts.BOARD_ROWS)]
    mines = []
    place_flag()
    scatter_mines()

def flag_top_left():
    """Calculating coordinates for the flag"""
    return (consts.BOARD_ROWS - consts.FLAG_ROWS,
            consts.BOARD_COLS - consts.FLAG_COLS)


def place_flag():
    """Marks the flag cells in the matrix"""
    top, left = flag_top_left()
    for row in range(top, top + consts.FLAG_ROWS):
        for col in range(left, left + consts.FLAG_COLS):
            matrix[row][col] = consts.FLAG



def scatter_mines():
    """scatters MINES_COUNT mines at valid random locations"""
    placed = 0
    while placed < consts.MINES_COUNT:
        row = random.randint(0, consts.BOARD_ROWS - consts.MINE_ROWS)
        # שהמוקש בן שלוש המשבצות ייכנס בתוך הלוח
        col = random.randint(0, consts.BOARD_COLS - consts.MINE_COLS)
        if can_place_mine(row, col):
            put_mine(row, col)
            placed += 1


def can_place_mine(row, col):
    """checks that the matrix is empty at this location (no flag , soldier or other mine)"""
    if row < consts.SOLDIER_ROWS and col < consts.SOLDIER_COLS:
        return False

    left = max(0, col - consts.MINE_GAP)
    right = min(consts.BOARD_COLS - 1, col + consts.MINE_COLS - 1 + consts.MINE_GAP)
    for check_col in range(left, right + 1):
        if matrix[row][check_col] != consts.EMPTY:
            return False
    return True


def put_mine(row, col):
    """Marks the three mine squares and adds it to the list of mines"""
    for i in range(consts.MINE_COLS):
        matrix[row][col + i] = consts.MINE
    mines.append((row, col))



def any_cell_has(cells, marker):
    """Does the square touch a mine"""
    return any(matrix[row][col] == marker for row, col in cells)


def touches_flag(cells):
    """Does the square touch a flag"""
    return any_cell_has(cells, consts.FLAG)


def touches_mine(cells):
    """Does the square touch a mine(checks lose)"""
    return any_cell_has(cells, consts.MINE)
