import random
import pygame
import consts
import game_field
import soldier


def create_game_window():
    pygame.init()

    width = consts.WINDOW_WIDTH
    height = consts.WINDOW_HEIGHT
    window_surface = pygame.display.set_mode((width, height))

    pygame.display.set_caption(consts.WINDOW_TITLE)

    return window_surface


def load_game_images():
    images_dictionary = {}
    soldier_raw = pygame.image.load(consts.SOLDIER_IMAGE).convert_alpha()
    images_dictionary["soldier"] = pygame.transform.scale(soldier_raw,
                                                          consts.SOLDIER_PIXEL_SIZE)

    flag_raw = pygame.image.load(consts.FLAG_IMAGE).convert_alpha()
    images_dictionary["flag"] = pygame.transform.scale(flag_raw,
                                                       consts.FLAG_PIXEL_SIZE)

    mine_raw = pygame.image.load(consts.MINE_IMAGE).convert_alpha()
    images_dictionary["mine"] = pygame.transform.scale(mine_raw,
                                                       consts.MINE_PIXEL_SIZE)

    images_dictionary["bush"] = pygame.image.load(
        consts.BUSH_IMAGE).convert_alpha()

    return images_dictionary


def generate_bushes_positions():
    """distributes the bushes (flowers) randomly across the screen and checks that they do not overlap"""
    bushes_list = []
    bush_size = consts.BUSH_CELLS * consts.CELL_SIZE
    attempts = 0

    while len(
            bushes_list) < consts.BUSHES_COUNT and attempts < consts.BUSH_PLACE_ATTEMPTS:
        attempts += 1

        #Flower location lottery
        size =bush_size
        x = random.randint(0, consts.WINDOW_WIDTH - size)
        y = random.randint(0, consts.WINDOW_HEIGHT - size)

        candidate_rect = pygame.Rect(x, y, size, size)

        #Check that they do not merge.
        has_collision = False
        for existing_bush in bushes_list:
            if candidate_rect.colliderect(existing_bush):
                has_collision = True

        #if they dont merge add them
        if not has_collision:
            bushes_list.append(candidate_rect)

    return bushes_list


def draw_background_field(window_surface):
    window_surface.fill(consts.FIELD_COLOR)


def draw_all_bushes(window_surface, images_dictionary, bushes_list):
    """flower is on screen"""
    for bush_rect in bushes_list:
        bush_image = images_dictionary["bush"]
        scaled_bush = pygame.transform.scale(bush_image, (bush_rect.width,
                                                          bush_rect.height))
        window_surface.blit(scaled_bush, bush_rect.topleft)


def draw_game_flag(window_surface, images_dictionary):
    """pos flag in pixels"""
    row, col = game_field.flag_top_left()
    pixel_x = col * consts.CELL_SIZE
    pixel_y = row * consts.CELL_SIZE

    window_surface.blit(images_dictionary["flag"], (pixel_x, pixel_y))


def draw_game_soldier(window_surface, images_dictionary):
    """pos soldier in pixels"""
    soldier_position = soldier.pixel_top_left()
    window_surface.blit(images_dictionary["soldier"], soldier_position)


def draw_welcome_text(window_surface):
    """writes welcome text"""
    font = pygame.font.SysFont(consts.FONT_NAME, consts.WELCOME_FONT_SIZE,
                               bold=True)

    # start drawing from the right side of the soldier
    start_x = consts.SOLDIER_COLS * consts.CELL_SIZE + consts.CELL_SIZE
    current_y = consts.CELL_SIZE // 2

    message_lines = consts.WELCOME_MESSAGE.split("\n")
    for line in message_lines:
        text_image = font.render(line, True, consts.WELCOME_TEXT_COLOR)
        window_surface.blit(text_image, (start_x, current_y))
        current_y += font.get_linesize()


def draw_reveal_mode(window_surface, images_dictionary):
    """if enter was pressed show screen with mines + flag and soldier"""
    window_surface.fill(consts.REVEAL_BG_COLOR)


    for x in range(0, consts.WINDOW_WIDTH + 1, consts.CELL_SIZE):
        pygame.draw.line(window_surface, consts.GRID_LINE_COLOR, (x, 0),
                         (x, consts.WINDOW_HEIGHT))


    for y in range(0, consts.WINDOW_HEIGHT + 1, consts.CELL_SIZE):
        pygame.draw.line(window_surface, consts.GRID_LINE_COLOR, (0, y),
                         (consts.WINDOW_WIDTH, y))

    #plassing mines in their pixels using x and y
    for row, col in game_field.mines:
        pixel_x = col * consts.CELL_SIZE
        pixel_y = row * consts.CELL_SIZE
        window_surface.blit(images_dictionary["mine"], (pixel_x, pixel_y))

    #draw flag and soldier on top of the rows and cols
    draw_game_flag(window_surface, images_dictionary)
    draw_game_soldier(window_surface, images_dictionary)


def draw_popup_message(window_surface, text, color):
    """lose or win massagw"""
    font = pygame.font.SysFont(consts.FONT_NAME, consts.MESSAGE_FONT_SIZE,
                               bold=True)
    text_image = font.render(text, True, color)

#place the text in the middle
    center_x = consts.WINDOW_WIDTH // 2
    center_y = consts.WINDOW_HEIGHT // 2
    text_rect = text_image.get_rect(center=(center_x, center_y))

    padding_x = consts.CELL_SIZE * 2
    padding_y = consts.CELL_SIZE
    box_rect = text_rect.inflate(padding_x, padding_y)

    pygame.draw.rect(window_surface, consts.MESSAGE_BOX_COLOR, box_rect)
    window_surface.blit(text_image, text_rect)


def update_display():
    """new updated screen"""
    pygame.display.flip()
