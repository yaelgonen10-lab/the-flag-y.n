import consts

DIRECTIONS = {
    "up": (-1, 0),
    "down": (1, 0),
    "left": (0, -1),
    "right": (0, 1),
}

#soldiers pos
position = [consts.SOLDIER_START_ROW, consts.SOLDIER_START_COL]


def create():
    """Places the soldier at the starting position"""
    global position
    position = [consts.SOLDIER_START_ROW, consts.SOLDIER_START_COL]


def body_cells():
    """body list"""
    top, left = position
    return [(top + row, left + col)
            for row in range(consts.SOLDIER_BODY_ROWS)
            for col in range(consts.SOLDIER_COLS)]


def feet_cells():
    """feet list"""
    top, left = position
    feet_top = top + consts.SOLDIER_BODY_ROWS
    return [(feet_top + row, left + col)
            for row in range(consts.SOLDIER_FEET_ROWS)
            for col in range(consts.SOLDIER_COLS)]


def can_move(direction):
    """if possible move out of matrix"""
    delta_row, delta_col = DIRECTIONS[direction]
    new_top = position[0] + delta_row
    new_left = position[1] + delta_col
    return (0 <= new_top
            and new_top + consts.SOLDIER_ROWS <= consts.BOARD_ROWS
            and 0 <= new_left
            and new_left + consts.SOLDIER_COLS <= consts.BOARD_COLS)


def move(direction):
    """moves the soldier"""
    delta_row, delta_col = DIRECTIONS[direction]
    position[0] += delta_row
    position[1] += delta_col


def pixel_top_left():
    """pos soldier in pixels"""
    return (position[1] * consts.CELL_SIZE, position[0] * consts.CELL_SIZE)

